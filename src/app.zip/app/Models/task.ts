export class Task {
    Task: string;
    ParentTask: string;
    StartDate: Date;
    EndDate: Date;
    Priority: number;
    ParentTaskId: number;
}


export const taskData: any=""; 