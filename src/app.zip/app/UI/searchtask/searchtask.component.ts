import { Component, OnInit } from '@angular/core';
import { Task, taskData } from '../../Models/task';
import { SharedService } from '../../Services/shared.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-searchtask',
  templateUrl: './searchtask.component.html',
  styleUrls: ['./searchtask.component.css'],
  providers:[SharedService]
})
export class SearchtaskComponent implements OnInit {
  taskList: Task[];
  taskListFiltered: Task[];
  taskName: string;
  pTaskName: string;
  startDate: Date;
  endDate: Date;
  priorityFrom: number;
  priorityTo: number;

  // _service:SharedService,
  constructor(private  _router:Router, public _service:SharedService) {  
    this.taskList=[ 
           {Task:"Task1",ParentTask:"Task0",Priority:3,StartDate:new Date('08-02-2018'),EndDate:new Date('08-04-2018'),ParentTaskId:0},     
           {Task:"Task2",ParentTask:"Task1",Priority:5,StartDate:new Date('08-05-2018'),EndDate:new Date('08-09-2018'),ParentTaskId:1},     
           {Task:"Task3",ParentTask:"Task2",Priority:4,StartDate:new Date('08-15-2018'),EndDate:new Date('08-20-2018'),ParentTaskId:2},     
           {Task:"Task4",ParentTask:"Task3",Priority:7,StartDate:new Date('08-20-2018'),EndDate:new Date('08-28-2018'),ParentTaskId:3},     
           {Task:"Task5",ParentTask:"Task4",Priority:9,StartDate:new Date('08-25-2018'),EndDate:new Date('08-30-2018'),ParentTaskId:4},    
    ] 

    this.taskListFiltered = this.taskList;

  }

  ngOnInit() {
  }

  SearchByTask()
  {
this.taskListFiltered = this.taskList.filter(x=> x.Task.toLowerCase().includes(this.taskName.toLowerCase()));
  }

  SearchByParentTask()
  {
this.taskListFiltered = this.taskList.filter(x=> x.ParentTask.toLowerCase().includes(this.pTaskName.toLowerCase()));
  }

  SearchByPriority()
  {
if(this.priorityFrom != null && this.priorityTo != null && this.priorityTo >= this.priorityFrom){
this.taskListFiltered = this.taskList.filter(x=> (x.Priority <= this.priorityTo && x.Priority >= this.priorityFrom ));
}
    
  }

  SearchByDate() {

    console.log(this.taskList)

    this.startDate = this.startDate == null ? null : (this.startDate.toString() == "" ?  null : this.startDate);
    this.endDate = this.endDate == null ? null : (this.endDate.toString() == "" ?  null : this.endDate);

    if (this.startDate != null && this.endDate != null && this.endDate >= this.startDate) {
      this.taskListFiltered = this.taskList.filter(x => (x.StartDate.toDateString() == new Date(this.startDate.toString()).toDateString() && x.EndDate.toDateString() == new Date(this.endDate.toString()).toDateString()));
    } else
      if (this.startDate != null && this.endDate == null) {
        this.taskListFiltered = this.taskList.filter(x => (x.StartDate.toDateString() == new Date(this.startDate.toString()).toDateString()));
      } else
        if (this.startDate == null && this.endDate != null) {
          this.taskListFiltered = this.taskList.filter(x => (x.EndDate.toDateString() == new Date(this.endDate.toString()).toDateString()));
        }
  }


  EditTask(data:any)
  {
      this._service.GetSetTaskData(data);
      this._router.navigateByUrl('/Edit');
  }

  EndTask()
  {

  }

  AddTask(){
    this._router.navigateByUrl('/Add');
  }

  ViewTask(){
    this._router.navigateByUrl('');
  }
}
