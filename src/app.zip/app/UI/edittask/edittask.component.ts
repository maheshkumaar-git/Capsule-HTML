import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../Services/shared.service';
import { Task } from '../../Models/task';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edittask',
  templateUrl: './edittask.component.html',
  styleUrls: ['./edittask.component.css'],
  providers:[SharedService]
})
export class EdittaskComponent implements OnInit {

  
  taskName : string;
  pTaskName : String;
  priority: number;
  sDate :Date;
  eDate:Date;
  editTaskData :Task;

  


  constructor(private  _router:Router, public _service:SharedService) { }

  ngOnInit() {
    this.editTaskData =  this._service.GetSetTaskData("");
  }

  UpdateTask()
  {

  }

  Cancel(){
    this._router.navigateByUrl('');
  }

}
