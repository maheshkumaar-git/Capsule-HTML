import { Component, OnInit, NgModule } from '@angular/core';
import { EdittaskComponent } from '../edittask/edittask.component';
import { SearchtaskComponent } from 'src/app/UI/searchtask/searchtask.component';
import { RouterModule, Route, Router } from '@angular/router';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {

  taskName : string;
  pTaskName : String;
  priority: number =1;
  sDate :Date;
  eDate:Date;


  constructor(private  _router:Router) { }

  ngOnInit() {
  }

  Reset(){
    this.taskName= "";
    this.pTaskName ="";
    this.priority = 1;
    this.sDate = null;
    this.eDate =null;
  }

  Add(){
    this._router.navigateByUrl('/Add');
  }

  ViewTask(){
    this._router.navigateByUrl('');
  }
}


