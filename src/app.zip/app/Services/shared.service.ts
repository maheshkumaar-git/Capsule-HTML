import { Injectable } from '@angular/core';
import { taskData } from '../Models/task';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  taskdata: any;
  constructor() { }

  
GetSetTaskData(data:any):any
{
  if(data == "" || data == null)
  return this.taskdata;
  else
  this.taskdata;
}
}
